import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css';

/*
 * Persistence shim: the app calls window.storage (get/set/delete/list).
 * Inside this installed Android app we back it with IndexedDB, which persists
 * across launches and holds far more than localStorage (important for photos).
 */
(function () {
  const DB_NAME = 'hortiscan-db';
  const STORE = 'kv';
  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => { req.result.createObjectStore(STORE); };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  function run(mode, fn) {
    return openDB().then(db => new Promise((resolve, reject) => {
      const tx = db.transaction(STORE, mode);
      const store = tx.objectStore(STORE);
      const request = fn(store);
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    }));
  }
  if (!window.storage) {
    window.storage = {
      async get(key) {
        const v = await run('readonly', s => s.get(key));
        return (v === undefined || v === null) ? null : { key, value: v };
      },
      async set(key, value) {
        await run('readwrite', s => s.put(value, key));
        return { key, value };
      },
      async delete(key) {
        await run('readwrite', s => s.delete(key));
        return { key, deleted: true };
      },
      async list(prefix = '') {
        const keys = await run('readonly', s => s.getAllKeys());
        return { keys: (keys || []).filter(k => String(k).startsWith(prefix)), prefix };
      }
    };
  }
})();

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
